local E, L, V, P, G = unpack(ElvUI)
local EP = LibStub("LibElvUIPlugin-1.0")
local addon, ns = ...

-- Create the plugin module
local EC = E:NewModule('Controller', 'AceHook-3.0', 'AceEvent-3.0', 'AceTimer-3.0')
local DEFAULT_WIDTH = 890
local DEFAULT_HEIGHT = 650
local AC = E:GetModule('ActionBars')

-- Default options
P.Controller = {
    enabled = true,
    layout = "Xbox",
    bindings = {},
    numPages = 2,
}

-- Button labels for controller layouts
local controllerLayouts = {
    Xbox = { A = "A", B = "B", X = "X", Y = "Y", LB = "LB", RB = "RB", LT = "LT", RT = "RT" },
    PlayStation = { Cross = "Cross", Circle = "Circle", Square = "Square", Triangle = "Triangle", L1 = "L1", R1 = "R1", L2 = "L2", R2 = "R2" },
    Nintendo = { A = "A", B = "B", X = "X", Y = "Y", L = "L", R = "R", ZL = "ZL", ZR = "ZR" },
}

-- Setup installer
local function SetupInstaller()
    EC.InstallerData = {
        Title = "|cff1784d1ElvUI|r |cffffffffController|r",
        Name = "Controller",
        tutorialImage = nil, -- Use the logo as tutorial image
        Pages = {
            [1] = function()
                PluginInstallFrame.SubTitle:SetText("Welcome")
                PluginInstallFrame.Desc1:SetText("This plugin allows you to use a controller with ElvUI in a FFXIV-style crossbar layout.")
                PluginInstallFrame.Desc2:SetText("This installer will guide you through the process of setting up the controller interface.")
                PluginInstallFrame.Option1:Show()
                PluginInstallFrame.Option1:SetText("Install")
                PluginInstallFrame.Option1:SetScript("OnClick", function() PluginInstallFrame.Next:Click() end)
            end,
            [2] = function()
                PluginInstallFrame.SubTitle:SetText("Controller Layout")
                PluginInstallFrame.Desc1:SetText("Choose your controller type:")
                PluginInstallFrame.Option1:Show()
                PluginInstallFrame.Option1:SetText("Xbox")
                PluginInstallFrame.Option1:SetScript("OnClick", function() E.db.Controller.layout = "Xbox"; PluginInstallFrame.Next:Click() end)
                PluginInstallFrame.Option2:Show()
                PluginInstallFrame.Option2:SetText("PlayStation")
                PluginInstallFrame.Option2:SetScript("OnClick", function() E.db.Controller.layout = "PlayStation"; PluginInstallFrame.Next:Click() end)
                PluginInstallFrame.Option3:Show()
                PluginInstallFrame.Option3:SetText("Nintendo")
                PluginInstallFrame.Option3:SetScript("OnClick", function() E.db.Controller.layout = "Nintendo"; PluginInstallFrame.Next:Click() end)
            end,
            [3] = function()
                PluginInstallFrame.SubTitle:SetText("Installation Complete")
                PluginInstallFrame.Desc1:SetText("You have completed the installation process.")
                PluginInstallFrame.Desc2:SetText("Please click the button below to finish the installation and reload your UI.")
                PluginInstallFrame.Option1:Show()
                PluginInstallFrame.Option1:SetText("Finished")
                PluginInstallFrame.Option1:SetScript("OnClick", function() 
                    E:StaticPopup_Show("ELVUI_EDITBOX", nil, nil, "Controller installation complete!")
                    ReloadUI()
                end)
            end,
        },
        StepTitles = {
            [1] = "Welcome",
            [2] = "Controller Layout",
            [3] = "Installation Complete",
        },
        StepTitlesColor = {1, 1, 1},
        StepTitlesColorSelected = {0, 179/255, 1},
        StepTitleWidth = 200,
        StepTitleButtonWidth = 180,
        StepTitleTextJustification = "CENTER",
    }
end

-- Initialize the plugin
function EC:Initialize()
    -- Register plugin with ElvUI
    EP:RegisterPlugin(addon, EC.InsertOptions)
    
    -- Create default settings if they don't exist
    if not E.db.Controller then
        E.db.Controller = P.Controller
    end
    
    -- Setup installer
    SetupInstaller()
    
    -- Register events
    self:RegisterEvent("PLAYER_ENTERING_WORLD", "SetupCrossbar")
    
    -- Setup initial state
    self:ToggleCrossbar(E.db.Controller.enabled)
end

-- Set up the options
function EC:InsertOptions()
    E.Options.args.Controller = {
        order = 100,
        type = "group",
        name = "Controller",
        args = {
            header = {
                order = 1,
                type = "header",
                name = "ElvUI Controller",
            },
            install = {
                order = 2,
                type = "execute",
                name = "Install",
                desc = "Run the installation process.",
                func = function() E:GetModule("PluginInstaller"):Queue(EC.InstallerData); end,
            },
            enable = {
                type = "toggle",
                name = "Enable",
                order = 3,
                get = function() return E.db.Controller.enabled end,
                set = function(_, value)
                    E.db.Controller.enabled = value
                    EC:ToggleCrossbar(value)
                end,
            },
            layout = {
                type = "select",
                name = "Controller Layout",
                order = 4,
                values = { Xbox = "Xbox", PlayStation = "PlayStation", Nintendo = "Nintendo" },
                get = function() return E.db.Controller.layout end,
                set = function(_, value) E.db.Controller.layout = value end,
            },
            numPages = {
                type = "range",
                name = "Number of Pages",
                order = 5,
                min = 2,
                max = 8,
                step = 1,
                get = function() return E.db.Controller.numPages end,
                set = function(_, value) E.db.Controller.numPages = value end,
            },
        }
    }
end

-- Setup crossbar
function EC:SetupCrossbar()
    print("ElvUI Controller loaded!")
    -- Your setup code here
end

-- Toggle crossbar visibility
function EC:ToggleCrossbar(enable)
    if enable then
        -- Enable the crossbar and begin monitoring inputs
        print("Controller mode enabled")
    else
        -- Disable the crossbar
        print("Controller mode disabled")
    end
end

-- Handle controller binding
function EC:BindControllerButtons()
    -- Capture controller button press
    local buttonPressed = GetPressedControllerButton()
    -- Save the button mapping
    self:UpdateBinding(buttonPressed)
end

-- Update controller binding
function EC:UpdateBinding(buttonPressed)
    local layout = E.db.Controller.layout
    local binding = controllerLayouts[layout][buttonPressed]
    
    if binding then
        -- Save the binding to the appropriate page
        local page = E.db.Controller.numPages
        E.db.Controller.bindings["Page " .. page] = binding
    end
end

E:RegisterModule(EC:GetName())
